# CombiParser
A simple combinator parser written in Python. Probably not efficient or bug-free, but a useful learning exercise in implementing a functional idea I learnt in Haskell, in an imperative/OOP language such as Python.
